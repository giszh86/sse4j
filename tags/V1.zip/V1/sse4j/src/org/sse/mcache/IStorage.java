package org.sse.mcache;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public interface IStorage {
	String getKey();
}
