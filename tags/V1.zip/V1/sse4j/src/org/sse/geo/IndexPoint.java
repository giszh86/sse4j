package org.sse.geo;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class IndexPoint {
	public int idx;
	public Point pt;

	public IndexPoint(int idx, Point pt) {
		this.idx = idx;
		this.pt = pt;
	}
}
