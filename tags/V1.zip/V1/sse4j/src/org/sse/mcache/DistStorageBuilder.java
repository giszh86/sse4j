package org.sse.mcache;

import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.TermDocs;
import org.sse.NaviConfig;
import org.sse.geoc.DistPtyName;
import org.sse.io.IdxReader;
import org.sse.squery.Searcher;
import org.sse.util.MercatorUtil;

import com.vividsolutions.jts.geom.Envelope;
import com.vividsolutions.jts.geom.Geometry;
import com.vividsolutions.jts.index.SpatialIndex;
import com.vividsolutions.jts.index.strtree.STRtree;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class DistStorageBuilder implements IStorageBuilder {

	@Override
	public IStorage create(Map<String, String> map) throws Exception {
		Envelope ext = null;
		IdxReader reader = new IdxReader(map.get("item-path"));
		TermDocs docs = reader.getReader().termDocs();
		Map<String, Geometry> geos = new HashMap<String, Geometry>(reader
				.getReader().numDocs());
		SpatialIndex idx = new STRtree();
		while (docs.next()) {
			Document doc = reader.getReader().document(docs.doc());
			Geometry g = MercatorUtil.toGeometry(doc.get(DistPtyName.GID),
					NaviConfig.WGS);
			idx.insert(g.getEnvelopeInternal(), doc.get(DistPtyName.OID));
			geos.put(doc.get(DistPtyName.OID), g);
			if (ext == null)
				ext = g.getEnvelopeInternal();
			else
				ext.expandToInclude(g.getEnvelopeInternal());
		}
		docs.close();
		Searcher.getInstance().put(map.get("item-path"), reader, idx, ext);

		return new DistStorage(map.get("item-path"), geos);
	}

}
