package org.sse.geoc;

import org.sse.squery.PtyName;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class DistPtyName extends PtyName {
	public static String CITYCODE = "CITYCODE";
	public static String PROVCODE = "PROVCODE";
	public static String PROVINCE = "PROVINCE";
	public static String CITY = "CITY";
	public static String COUNTY = "COUNTY";
}
