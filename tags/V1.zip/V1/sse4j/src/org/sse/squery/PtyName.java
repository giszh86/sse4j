package org.sse.squery;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class PtyName {
	public static String OID = "ID";
	public static String GID = "GEOMETRY";
	public static String TITLE = "NAMEC";
}
