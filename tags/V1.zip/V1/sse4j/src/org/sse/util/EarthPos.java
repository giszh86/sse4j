package org.sse.util;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class EarthPos {
	public double xLon;
	public double yLat;

	public EarthPos(double xLon, double yLat) {
		this.xLon = xLon;
		this.yLat = yLat;
	}
}
