package org.sse.service.base;

import org.sse.squery.PtyName;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class PoiPtyName extends PtyName {
	public static String NAMEC = "NAMEC";
	public static String NAMEP = "NAMEP";
	public static String KIND = "KIND";
	public static String TYPE = "TYPE";
	public static String TEL = "TEL";
	public static String ADDRESS = "ADDRESS";
}
