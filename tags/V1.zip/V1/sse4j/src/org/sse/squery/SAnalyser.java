package org.sse.squery;

import java.util.List;

import com.vividsolutions.jts.geom.Envelope;

/**
 * 
 * @author dux(duxionggis@126.com)
 * 
 */
public class SAnalyser {
	public List<String> spatialFilter(List<String> objs, Envelope extent,
			double distance) {
		return null;
	}
}
